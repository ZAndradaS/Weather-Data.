import edu.duke.*;
import org.apache.commons.csv.*;
import java.io.*;

public class Weather_Data {

    public CSVRecord coldestHourInFile(CSVParser parser) {
        CSVRecord coldestSoFar = null;
        for (CSVRecord currentRow : parser) {
            // Get the current temperature and ignore the invalid readings
            double currentTemp = Double.parseDouble(currentRow.get("TemperatureF"));
            if (coldestSoFar == null && currentTemp != -9999) {
                coldestSoFar = currentRow;
            } else if (currentTemp != -9999) {
                double coldestTemp = Double.parseDouble(coldestSoFar.get("TemperatureF"));
                if (currentTemp < coldestTemp) {
                    coldestSoFar = currentRow;
                }
            }
        }
        return coldestSoFar;
    }

    // 2. fileWithColdestTemperature
    public String fileWithColdestTemperature() {
        CSVRecord coldestSoFar = null;
        String coldestFile = null;

        DirectoryResource dr = new DirectoryResource();  // Allow user to select multiple files
        for (File f : dr.selectedFiles()) {
            FileResource fr = new FileResource(f);  // Open each selected file
            CSVParser parser = fr.getCSVParser();  // Get the CSV parser for each file
            CSVRecord currentColdest = coldestHourInFile(parser);  // Find the coldest hour in this file

            if (coldestSoFar == null) {
                coldestSoFar = currentColdest;
                coldestFile = f.getName();  // Record the file name
            } else {
                double currentTemp = Double.parseDouble(currentColdest.get("TemperatureF"));
                double coldestTemp = Double.parseDouble(coldestSoFar.get("TemperatureF"));

                if (currentTemp < coldestTemp) {
                    coldestSoFar = currentColdest;
                    coldestFile = f.getName();
                }
            }
        }

        return coldestFile;
    }
    
    public void testColdestHourInFile() {
    // Open the file and parse it
    FileResource fr = new FileResource();  // You will select the file through a dialog box
    CSVParser parser = fr.getCSVParser();  // Create a parser for the file
    
    // Call the coldestHourInFile method to find the coldest temperature
    CSVRecord coldest = coldestHourInFile(parser);
    
    // Print the results
    System.out.println("Coldest temperature was " + coldest.get("TemperatureF") + 
                        " at " + coldest.get("DateUTC"));
    }


    public void testFileWithColdestTemperature() {
    String coldestFile = fileWithColdestTemperature();  // Identify the file with the coldest temp
    System.out.println("Coldest day was in file " + coldestFile);  // Print which file had the coldest temp

    // Now re-open the correct file to print all temperatures for that day
    FileResource fr = new FileResource("C:/Users/ACER/Desktop/Parsing Weather Data/2014/" + coldestFile);  // Ensure the path includes the file name
    CSVParser parser = fr.getCSVParser();  // Get a new parser for the coldest day file
    CSVRecord coldest = coldestHourInFile(parser);  // Find the coldest hour in this file

    System.out.println("Coldest temperature on that day was " + coldest.get("TemperatureF"));

    // Now print all the temperatures on that day
    parser = fr.getCSVParser();  // Reset the parser again
    System.out.println("All the Temperatures on the coldest day were:");
    for (CSVRecord record : parser) {
        System.out.println(record.get("DateUTC") + ": " + record.get("TemperatureF"));
    }
    }


    // 3. lowestHumidityInFile
    public CSVRecord lowestHumidityInFile(CSVParser parser) {
        CSVRecord lowestSoFar = null;
        for (CSVRecord currentRow : parser) {
            String humidityStr = currentRow.get("Humidity");
            if (!humidityStr.equals("N/A")) {
                double currentHumidity = Double.parseDouble(humidityStr);
                if (lowestSoFar == null) {
                    lowestSoFar = currentRow;
                } else {
                    double lowestHumidity = Double.parseDouble(lowestSoFar.get("Humidity"));
                    if (currentHumidity < lowestHumidity) {
                        lowestSoFar = currentRow;
                    }
                }
            }
        }
        return lowestSoFar;
    }

    public void testLowestHumidityInFile() {
        FileResource fr = new FileResource();
        CSVParser parser = fr.getCSVParser();
        CSVRecord lowestHumidity = lowestHumidityInFile(parser);
        System.out.println("Lowest Humidity was " + lowestHumidity.get("Humidity") + 
                           " at " + lowestHumidity.get("DateUTC"));
    }

    // 4. lowestHumidityInManyFiles
    public CSVRecord lowestHumidityInManyFiles() {
        CSVRecord lowestSoFar = null;

        DirectoryResource dr = new DirectoryResource();
        for (File f : dr.selectedFiles()) {
            FileResource fr = new FileResource(f);
            CSVParser parser = fr.getCSVParser();
            CSVRecord currentLowest = lowestHumidityInFile(parser);

            if (lowestSoFar == null) {
                lowestSoFar = currentLowest;
            } else {
                double currentHumidity = Double.parseDouble(currentLowest.get("Humidity"));
                double lowestHumidity = Double.parseDouble(lowestSoFar.get("Humidity"));

                if (currentHumidity < lowestHumidity) {
                    lowestSoFar = currentLowest;
                }
            }
        }

        return lowestSoFar;
    }

    public void testLowestHumidityInManyFiles() {
        CSVRecord lowestHumidity = lowestHumidityInManyFiles();
        System.out.println("Lowest Humidity was " + lowestHumidity.get("Humidity") +
                           " at " + lowestHumidity.get("DateUTC"));
    }

    // 5. averageTemperatureInFile
    public double averageTemperatureInFile(CSVParser parser) {
        double totalTemp = 0;
        int count = 0;

        for (CSVRecord record : parser) {
            double currentTemp = Double.parseDouble(record.get("TemperatureF"));
            totalTemp += currentTemp;
            count++;
        }

        return totalTemp / count;
    }

    public void testAverageTemperatureInFile() {
        FileResource fr = new FileResource();
        CSVParser parser = fr.getCSVParser();
        double averageTemp = averageTemperatureInFile(parser);
        System.out.println("Average temperature in file is " + averageTemp);
    }

    // 6. averageTemperatureWithHighHumidityInFile
    public double averageTemperatureWithHighHumidityInFile(CSVParser parser, int humidityValue) {
        double totalTemp = 0;
        int count = 0;

        for (CSVRecord record : parser) {
            String humidityStr = record.get("Humidity");
            if (!humidityStr.equals("N/A")) {
                double currentHumidity = Double.parseDouble(humidityStr);
                if (currentHumidity >= humidityValue) {
                    double currentTemp = Double.parseDouble(record.get("TemperatureF"));
                    totalTemp += currentTemp;
                    count++;
                }
            }
        }

        if (count == 0) {
            System.out.println("No temperatures with that humidity");
            return 0.0;
        }

        return totalTemp / count;
    }

    public void testAverageTemperatureWithHighHumidityInFile() {
        FileResource fr = new FileResource();
        CSVParser parser = fr.getCSVParser();
        double averageTemp = averageTemperatureWithHighHumidityInFile(parser, 80);
        if (averageTemp != 0.0) {
            System.out.println("Average Temp when high Humidity is " + averageTemp);
        }
    }
}
